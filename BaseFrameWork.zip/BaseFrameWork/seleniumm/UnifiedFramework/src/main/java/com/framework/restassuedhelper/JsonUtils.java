package com.framework.restassuedhelper;

import com.framework.config.PropertiesRepository;
import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Date;
import java.util.HashMap;


public class JsonUtils {
    private static JsonPath jsonPath;
    private static JSONObject jsonObject;
    private static Object object;
    private static String jsonInString;

    /*
     * convert Jsonfile to string
     */
    public String ToStringFile(String jsonFilePath) throws Exception {
        try {
            object = new JSONParser().parse(new FileReader(System.getProperty("user.dir") + jsonFilePath + ".json"));
            jsonObject = (JSONObject) object;
            jsonInString = (String) jsonObject.toString();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return jsonInString;
    }

    /*
     * convert Json response to string
     */
    public String ToStringFile(Response response) throws Exception {
        try {
            jsonInString = response.toString();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return jsonInString;
    }

    /*
     * write Json response
     */
    public String writeJsonResponse(Response response, String filePath) {
        try {
            if (response != null) {
                jsonInString = response.asString();
                long timestamp = new Date().getTime();
                PrintWriter pw = new PrintWriter(System.getProperty("user.dir") + filePath + timestamp + ".json");
                pw.write(jsonInString);
                pw.flush();
                pw.close();
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return jsonInString;
    }

    /*
     * Returns JsonPath object
     */
    public JsonPath getJsonPath(Response response) {
        try {
            if (response != null) {
                String resultString = response.asString();
                jsonPath = new JsonPath(resultString);
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return jsonPath;
    }

    /*
     * get Json file content
     */
    public String ReadJsonFileContent(String filePath) throws Exception {
        String content = "";
        try {
            content = new String(Files.readAllBytes(Paths.get((System.getProperty("user.dir") + filePath + ".json"))));
        } catch (Exception e) {
            e.printStackTrace();
        }
        return content;
    }

    /*
     * method to edit multiple object of JsonFile
     */
    public String updateObjectsOfJsonFile(String filePath, HashMap<String, String> keysToBeUpdated) {
        String editedJson = null;
        try {
            object = new JSONParser().parse(new FileReader(filePath));
            jsonObject = (JSONObject) object;
            for (String entry : keysToBeUpdated.keySet())
                updateKeyObject(jsonObject, entry, keysToBeUpdated.get(entry));
            editedJson = (String) jsonObject.toString();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return editedJson;
    }

    /*
     * finding particular object and replacing with the new value
     */
    @SuppressWarnings("unchecked")
    public JSONObject updateKeyObject(JSONObject jsonObj, String keyToBeUpdated, String valueToBeUpdated) {
        try {
            for (Object keyObj : jsonObj.keySet()) {
                String key = (String) keyObj;
                Object valObj = jsonObj.get(key);
                if (valObj instanceof JSONObject) { // call printJSON on nested object
                    updateKeyObject((JSONObject) valObj, keyToBeUpdated, valueToBeUpdated);
                } else {
                    if (keyToBeUpdated.equals(key)) {
                        jsonObj.put(keyToBeUpdated, valueToBeUpdated);
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return jsonObj;
    }

    /*
     * method to remove objects from JsonFile
     */
    public String removeObjectFromJsonFile(String filePath, String objectToBeRemoved) {
        String editedJson = null;
        try {
            object = new JSONParser().parse(new FileReader(filePath));
            jsonObject = (JSONObject) object;
            jsonObject.remove(objectToBeRemoved);
            editedJson = (String) jsonObject.toString();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return editedJson;
    }

    public JSONObject getJSONObject(String filePath) throws Exception {
        try {
            object = new JSONParser().parse(new FileReader(filePath));
            jsonObject = (JSONObject) object;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return jsonObject;
    }

    public static void jsonCreater() throws IOException, ParseException {
        Object object = new JsonParser().parse(new FileReader(System.getProperty("user.dir") +
                PropertiesRepository.getString("payload.jsonpath") + "example.json"));
        String json = object.toString();
        Gson gson = new Gson();
        JsonObject inputObj = gson.fromJson(json, JsonObject.class);
        JsonObject newObject = new JsonObject();
        JsonArray jsonArray = new JsonArray();
        for (int i = 0; i < 4; i++) {
            newObject.addProperty("productCode", "newValue");
            newObject.addProperty("renewalFlag", "newValue");
            newObject.addProperty("productrequestType", "newValue");
            newObject.addProperty("discountCode", "newValue");
            newObject.addProperty("quantity", "newValue");
            newObject.addProperty("numberofUsers", "newValue");
            newObject.addProperty("price", "newValue");
            newObject.addProperty("startDate", "newValue");
            newObject.addProperty("endDate", "newValue");
            newObject.addProperty("sellingTerm", "newValue");
            newObject.addProperty("chargeType", "newValue");
            newObject.addProperty("upgradeFlag", "newValue");
            newObject.addProperty("pricingRequired", "newValue");
            inputObj.get("productPriceLineItem").getAsJsonArray().add(newObject);
        }

        System.out.println(inputObj);
    }

}
