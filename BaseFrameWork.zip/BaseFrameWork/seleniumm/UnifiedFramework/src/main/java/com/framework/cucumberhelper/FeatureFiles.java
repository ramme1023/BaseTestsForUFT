package com.framework.cucumberhelper;


import com.framework.config.GlobalProperties;
import com.framework.config.PropertiesRepository;
import com.framework.utils.ExcelUtils;
import org.testng.annotations.DataProvider;


public class FeatureFiles {
    @DataProvider(name = CucumberConstants.DATAPROVIDERMETHOD)
    public Object[][] getTestDataFromExcel() {
        String filePath = System.getProperty("user.dir") + PropertiesRepository.getString("feature.excel.file");
        String[][] featureList = null;

        featureList = ExcelUtils.getFeatureFiles(filePath,  GlobalProperties.TestType);

        return featureList;
    }
}