package com.framework.cucumberhelper;

import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class RestAPIConstants {
    public static String BaseURI = null;
    public static String UserName = null;
    public static String Password = null;
    public static String Authorization = null;
    public static String Content = null;
    public static Response response = null;
    public static RequestSpecification request = null;
}
