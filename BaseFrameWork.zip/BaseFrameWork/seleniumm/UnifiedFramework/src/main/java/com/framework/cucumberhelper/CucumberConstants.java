package com.framework.cucumberhelper;

public class CucumberConstants {

	private CucumberConstants() {

	}

	public static final String DATAPROVIDERMETHOD = "featureList";
	public static final String EXECUTIONSTATUS = "Y";
	public static String SheetName = null;
	public static final String IMAGETYPE = "image/png";
}
