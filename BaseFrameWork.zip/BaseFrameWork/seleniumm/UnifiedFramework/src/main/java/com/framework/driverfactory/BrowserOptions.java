package com.framework.driverfactory;

import org.openqa.selenium.UnexpectedAlertBehaviour;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.remote.CapabilityType;

import com.framework.config.PropertiesRepository;

public class BrowserOptions {

	public static ChromeOptions setChromeOptions(String browserType) {
		ChromeOptions chromeOptions = new ChromeOptions();
		chromeOptions.setUnhandledPromptBehaviour(UnexpectedAlertBehaviour.ACCEPT);
		chromeOptions.setAcceptInsecureCerts(true);
		chromeOptions.addArguments("--ignore-certificate-errors");
		chromeOptions.addArguments("--disable-popup-blocking");
		chromeOptions.setCapability(CapabilityType.BROWSER_NAME, browserType);

		
		
		//chromeOptions.setCapability(PropertiesRepository.getString("global.browser.capability.chrome.acceptSslCerts"), true);
		chromeOptions.setCapability("platform", PropertiesRepository.getString("global.browser.capability.platform"));
		chromeOptions.setCapability("takesScreenshot",
				PropertiesRepository.getBoolean("global.browser.capability.chrome.takesScreenshot"));
		chromeOptions.setCapability("handlesAlerts",
				PropertiesRepository.getBoolean("global.browser.capability.chrome.handlesAlerts"));
		chromeOptions.setCapability("cssSelectorsEnabled",
				PropertiesRepository.getBoolean("global.browser.capability.chrome.cssSelectorsEnabled"));
		
		return chromeOptions;
	}

}
