package com.framework.datahandler;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class DataHandler {

    Connection connection;
    Statement statement;
    ResultSet resultSet;

    public Connection connectToDatabase(String classForName, String url, String username, String password) {
        try {
            Class.forName(classForName);
            connection = DriverManager.getConnection(url, username, password);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return connection;
    }

    public Statement createStatement(Connection connection) {

        try {
            statement = connection.createStatement();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return statement;
    }

    public ResultSet getResultSet(Statement statement, String queryStatement) {

        try {
            resultSet = statement.executeQuery(queryStatement);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return resultSet;
    }

    public void closeDatabaseConnection(Connection connection, Statement statement, ResultSet resultSet) throws Exception {
        if (resultSet != null) {
            try {
                resultSet.close();
            } catch (Exception e) {
            }
        }

        if (statement != null) {
            try {
                statement.close();
            } catch (Exception e) {
            }
        }

        if (connection != null) {
            try {
                connection.close();
            } catch (Exception e) {
            }
        }
    }

}
