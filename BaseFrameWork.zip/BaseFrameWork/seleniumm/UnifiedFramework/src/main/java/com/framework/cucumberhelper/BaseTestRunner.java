package com.framework.cucumberhelper;

import java.io.File;
import java.nio.file.Paths;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.framework.config.GlobalProperties;
import com.framework.config.PropertiesRepository;
import com.framework.reports.CucumberAPIReports;
import com.framework.reports.CucumberReports;

public class BaseTestRunner {
	private static Logger logger = LogManager.getLogger(BaseTestRunner.class);
	private static String autmationType = "automation.type";

	static {
		try {
			PropertiesRepository.loadAllProperties();
		} catch (Exception e) {
			logger.error("Unable to load properties files", e);
		}
	}

	@Parameters({ "browser", "testtype", "suitename", "environment" })
	@BeforeSuite
	public void setUp(@Optional String browserType, @Optional String testType, @Optional String suiteName,
			@Optional String environment) {
		if (PropertiesRepository.getString(autmationType).equalsIgnoreCase(GlobalProperties.WEBDRIVERAUTOMATION)) {
			GlobalProperties.BrowserType = browserType;
			GlobalProperties.TestType = testType;
			GlobalProperties.SuiteName = suiteName;
			GlobalProperties.Environment = environment;
		} else if (PropertiesRepository.getString(autmationType)
				.equalsIgnoreCase(GlobalProperties.RESTAPIAUTOMATION)) {
			GlobalProperties.TestType = testType;
			GlobalProperties.SuiteName = suiteName;
		}

	}

	@Test(dataProvider = CucumberConstants.DATAPROVIDERMETHOD, dataProviderClass = FeatureFiles.class)
	public void runFeatures(String featureList, String tag, String status) {
		if (featureList != null && CucumberConstants.EXECUTIONSTATUS.equalsIgnoreCase(status)) {
			File[] fileList = getFileList(featureList);

			for (File feature : fileList) {
				TestNGRunnerHelper.runTestNG(feature.getPath(), tag);
			}

		}
	}

	@AfterSuite
	public void generateReport() {
		if (PropertiesRepository.getString(autmationType).equalsIgnoreCase(GlobalProperties.WEBDRIVERAUTOMATION)) {
			CucumberReports.generateCucumberReport(GlobalProperties.SuiteName);
		} else if (PropertiesRepository.getString(autmationType)
				.equalsIgnoreCase(GlobalProperties.RESTAPIAUTOMATION)) {
			CucumberAPIReports.generateCucumberReport(GlobalProperties.SuiteName);
		} else {
			CucumberAPIReports.generateCucumberReport(GlobalProperties.SuiteName);
		}
	}

	private static File[] getFileList(String dirPath) {
		final File file = Paths.get(dirPath).toFile();
		final String pattern = ".feature";

		return file.listFiles((pFile, pString) -> pString.endsWith(pattern));
	}
}
