package com.framework.restassuedhelper;

import java.io.*;

public class XmlUtils {

    public String xmlTotring(String filePath) throws IOException {
        String editedXML = null;
        File xmlFile = new File(filePath);
        Reader fileReader = new FileReader(xmlFile);
        BufferedReader bufReader = new BufferedReader(fileReader);
        StringBuilder sb = new StringBuilder();
        String line = bufReader.readLine();
        while (line != null) {
            sb.append(line).append("\n");
            line = bufReader.readLine();
        }
        editedXML= sb.toString();
        bufReader.close();

        return editedXML;
    }

}
