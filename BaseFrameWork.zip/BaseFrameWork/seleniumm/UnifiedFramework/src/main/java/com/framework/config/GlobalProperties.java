package com.framework.config;

public final class GlobalProperties {

	private GlobalProperties() {

	}

	// Exceptions constants
	public static final String PROPERTIESEXCEPTION = "Properties Exception : There was an error processing properties";
	public static final String SCREENSHOTPATH = System.getProperty("user.dir")
			+ PropertiesRepository.getString("screenshot.path");
	public static final String WEBDRIVERAUTOMATION = "webdriver";
	public static final String RESTAPIAUTOMATION = "restapi";

	// Browser Constants
	public static String BrowserType;
	public static String SuiteName;
	public static String Environment;
	public static String TestType;
	public static final String FIREFOX = "firefox";
	public static final String CHROME = "chrome";
	public static final String IE = "internet explorer";
	public static final String MICROSOFTEDGE = "edge";

	public static final String REGRESSIONTEST = "regression";
	public static final String SMOKETEST = "smoke";

	// Environments
	public static final String QAENVIRONMENT = "qa";
	public static final String UATENVIRONMENT = "uat";

	// Default wait - 10s
	public static final int EXPLICIT_WAIT = PropertiesRepository.getInt("global.driver.wait");

	// Default Properties Files
	public static final String PROPS_LIST = "prop-files.properties";
	public static final String GLOBAL_PROPS = "global.properties";
	public static final String LOG_PROPS = "log4j.properties";
	public static final String LOG_PROPS_HTML = "log4j-h.properties";
	public static final String EXTENT_REPORT_CONFIG = System.getProperty("user.dir")
			+ "/src/main/resources/ExtentReportConfig.xml";

}
