package com.framework.cucumberhelper;

import static java.util.Arrays.asList;

import java.util.ArrayList;
import java.util.List;

import com.framework.config.PropertiesRepository;

import cucumber.runtime.ClassFinder;
import cucumber.runtime.RuntimeOptions;
import cucumber.runtime.io.MultiLoader;
import cucumber.runtime.io.ResourceLoader;
import cucumber.runtime.io.ResourceLoaderClassFinder;



public class TestNGRunnerHelper {

    public static void runTestNG(String feature, String tag) {
        List<String> CucumberOpts = new ArrayList<String>();
        feature = feature.replace("\\", "/");
        String[] featureList = feature.split("/");
        String jsonFileName = (featureList[featureList.length - 1]).replace(".feature", ".json");

        if (tag.isEmpty() || tag == null) {
            CucumberOpts.add("--plugin");
            CucumberOpts.add("pretty");
            CucumberOpts.add("--plugin");
            CucumberOpts.add("json:target/json/" + jsonFileName);
            CucumberOpts.add("--glue");
            CucumberOpts.add(PropertiesRepository.getString("step.defination"));
            CucumberOpts.add(feature);
        } else {
            CucumberOpts.add("--plugin");
            CucumberOpts.add("pretty");
            CucumberOpts.add("--plugin");
            CucumberOpts.add("json:target/json/" + jsonFileName);
            CucumberOpts.add("--glue");
            CucumberOpts.add(PropertiesRepository.getString("step.defination"));
            CucumberOpts.add(feature);
            CucumberOpts.add("--tags");
            CucumberOpts.add(tag);
        }
        String[] argv = (String[]) CucumberOpts.toArray(new String[CucumberOpts.size()]);
        RuntimeOptions runtimeOptions = new RuntimeOptions(new ArrayList<String>(asList(argv)));
        ClassLoader classLoader = Thread.currentThread().getContextClassLoader();
        ResourceLoader resourceLoader = new MultiLoader(classLoader);
        ClassFinder classFinder = new ResourceLoaderClassFinder(resourceLoader, classLoader);

        /*PluginFactory pluginFactory = new PluginFactory();
        EventPublisher eventPublisher = new CanonicalOrderEventPublisher();


        Plugins plugins = new Plugins(classLoader, pluginFactory, eventPublisher, runtimeOptions);

        EventBus bus = new TimeServiceEventBus(TimeService.SYSTEM);
        FeatureLoader featureLoader = new FeatureLoader(resourceLoader);
        RerunFilters rerunFilters = new RerunFilters(runtimeOptions, featureLoader);
        Filters filters = new Filters(runtimeOptions, rerunFilters);
        RunnerSupplier runnerSupplier = new ThreadLocalRunnerSupplier(runtimeOptions, bus,
                new BackendModuleBackendSupplier(resourceLoader, classFinder, runtimeOptions));
        FeatureSupplier featureSupplier = new FeaturePathFeatureSupplier(featureLoader, runtimeOptions);
        ExecutorService executor = new ForkJoinPool();

        Runtime runtime = new Runtime(plugins, runtimeOptions, bus, filters,
                runnerSupplier, featureSupplier, executor);*/
        //Runtime runtime = new Runtime(resourceLoader, classFinder, classLoader, runtimeOptions);

        try {
           // runtime.run();
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

}
