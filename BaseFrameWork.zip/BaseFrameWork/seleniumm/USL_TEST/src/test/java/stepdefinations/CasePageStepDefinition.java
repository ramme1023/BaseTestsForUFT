package stepdefinations;

import org.openqa.selenium.WebDriver;

import com.framework.asserts.AssertionHandler;

import cucumber.api.java.en.Then;
import esc.usl.constants.USLegalConstants;
import esc.usl.pages.CasePage;
import esc.usl.pages.ContactPage;

public class CasePageStepDefinition {

	WebDriver driver;
	CasePage casePage;
	boolean flag;
	 
    public CasePageStepDefinition() {
        driver = CucumberSetup.getDriver();
        casePage = new CasePage(driver);
    }
    
    @Then("^The page is navigated to Case page$")
    public void the_page_is_navigated_to_case_page() {
    	flag = casePage.verifyCasePage();
		AssertionHandler.verifyTrue(flag, "Not navigated to CasePage");
		CucumberSetup.globalscenario.write("Navigated to CasePage");
		String caseNumber  = casePage.returnCaseNumber();
		CucumberSetup.globalscenario.write("Case Number: "+caseNumber);
		CucumberSetup.globalscenario.embed(CucumberSetup.attachScreenshot(), USLegalConstants.imageType);
    }
		 
}
