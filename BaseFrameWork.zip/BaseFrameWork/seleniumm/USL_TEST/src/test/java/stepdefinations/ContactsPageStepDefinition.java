package stepdefinations;

import org.openqa.selenium.WebDriver;

import com.framework.asserts.AssertionHandler;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import esc.usl.constants.USLegalConstants;
import esc.usl.pages.ContactPage;

public class ContactsPageStepDefinition {
	
	WebDriver driver;
	ContactPage contactpage;
	boolean flag;
	 
    public ContactsPageStepDefinition() {
        driver = CucumberSetup.getDriver();
        contactpage = new ContactPage(driver);
    }
    
	@Then("^The system displays the list of Contacts$")
    public void the_system_displays_the_list_of_contacts() {
		flag = contactpage.verifyContactList();
		AssertionHandler.verifyTrue(flag, "List of contacts are not displayed");
		CucumberSetup.globalscenario.write("List of contacts are displayed");
		CucumberSetup.globalscenario.embed(CucumberSetup.attachScreenshot(), USLegalConstants.imageType);
	}
	
	@And("^I should search for an existing contact$")
    public void i_should_search_for_an_existing_contact() {
		contactpage.searchContactName();
		CucumberSetup.globalscenario.write("Searched for an existing contact");
		CucumberSetup.globalscenario.embed(CucumberSetup.attachScreenshot(), USLegalConstants.imageType);
	}
	
	@Then("^The page is navigated to Contacts page$")
    public void the_page_is_navigated_to_contacts_page() {
		flag = contactpage.verifyContactPage();
		AssertionHandler.verifyTrue(flag, "Not navigated to Contacts page");
		CucumberSetup.globalscenario.write("Navigated to Contacts page");
		CucumberSetup.globalscenario.embed(CucumberSetup.attachScreenshot(), USLegalConstants.imageType);
	}
	
	@And("^I click on 'New Service Case' button$")
    public void i_click_on_new_service_case_button() {
		
	}

}
