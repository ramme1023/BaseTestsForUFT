package stepdefinations;

import cucumber.api.java.en.Then;
import org.openqa.selenium.WebDriver;

import cucumber.api.java.en.Given;
import esc.usl.constants.USLegalConstants;
import esc.usl.pages.BasePage;

public class BaseStepDefinition {

	WebDriver driver;
	BasePage basePage;

	public BaseStepDefinition() {
		driver = CucumberSetup.getDriver();
		basePage = new BasePage(driver);
	}

	@Then("^I am logged into SFDC as an Agent$")
	public void i_am_logged_into_sfdc_as_an_agent(){
		basePage.launchApplicationUrl();
		CucumberSetup.globalscenario.write("Navigated to the test URL");
		CucumberSetup.globalscenario.embed(CucumberSetup.attachScreenshot(), USLegalConstants.imageType);
		basePage.loginToApplication();
		CucumberSetup.globalscenario.write("Logged into the application");
		CucumberSetup.globalscenario.embed(CucumberSetup.attachScreenshot(), USLegalConstants.imageType);
	}
}
