package stepdefinations;

import org.openqa.selenium.WebDriver;

import cucumber.api.java.en.When;
import esc.usl.constants.USLegalConstants;
import esc.usl.pages.HomePage;

public class HomePageStepDefinition {

	WebDriver driver;
	HomePage homePage;

	public HomePageStepDefinition() {
		driver = CucumberSetup.getDriver();
		homePage = new HomePage(driver);
	}

	@When("^I select CONTACTS in the Navigation tab$")
	public void i_select_contacts_in_the_navigation_tab() {
		homePage.navigateToContactsTab();
		CucumberSetup.globalscenario.write("Navigating to Contacts Page");
		CucumberSetup.globalscenario.embed(CucumberSetup.attachScreenshot(), USLegalConstants.imageType);
	}
	


}
