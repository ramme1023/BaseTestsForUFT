package stepdefinations;

import com.framework.asserts.SoftAssertionHandler;
import com.framework.config.GlobalProperties;
import com.framework.config.PropertiesRepository;
import com.framework.cucumberhelper.RestAPIConstants;
import com.framework.driverfactory.DriverFactory;
import com.framework.reports.CucumberReports;
import cucumber.api.Scenario;
import cucumber.api.java.After;
import cucumber.api.java.Before;
import org.apache.commons.io.FileUtils;
import org.apache.commons.io.IOUtils;
import org.openqa.selenium.*;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

public class CucumberSetup {
    public static Scenario globalscenario;
    public static String browserType;
    protected static WebDriver driver = null;
    public List<String> CucumberOpts = new ArrayList<String>();

    public static byte[] attachScreenshot() {
        File screenshot;
        byte[] screenshotArray = null;
        try {
            screenshot = takeScreenShots("screenshot");
            InputStream screenshotStream = new FileInputStream(screenshot);
            screenshotArray = IOUtils.toByteArray(screenshotStream);
        } catch (IOException e) {
            e.printStackTrace();
        }

        return screenshotArray;

    }

    public static File takeScreenShots(String picture) throws IOException {
        File temp = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
        FileUtils.copyFile(temp, new File(GlobalProperties.SCREENSHOTPATH + File.separator + picture));
        return temp;
    }

    public static byte[] getElementScreenshot(WebElement webElement) throws IOException {
        byte[] screenshotArray = null;
        File screenshot = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
        BufferedImage fullImg = ImageIO.read(screenshot);

// Get the location of element on the page
        Point point = webElement.getLocation();

// Get width and height of the element
        int eleWidth = webElement.getSize().getWidth();
        int eleHeight = webElement.getSize().getHeight();

// Crop the entire page screenshot to get only element screenshot
        BufferedImage eleScreenshot = fullImg.getSubimage(point.getX(), point.getY(),
                eleWidth, eleHeight);
        ImageIO.write(eleScreenshot, "png", screenshot);

// Copy the element screenshot to disk
        File screenshotLocation = new File(GlobalProperties.SCREENSHOTPATH + File.separator + "sub_screenshot");
        FileUtils.copyFile(screenshot, screenshotLocation);
        InputStream screenshotStream = new FileInputStream(screenshotLocation);
        return IOUtils.toByteArray(screenshotStream);
    }

    public static WebDriver getDriver() {
        return driver;
    }

    @Before
    public void setUp(Scenario scenario) {
        if (PropertiesRepository.getString("automation.type").equalsIgnoreCase(GlobalProperties.WEBDRIVERAUTOMATION)) {
            browserType = GlobalProperties.BrowserType;
            driver = DriverFactory.getDriver(browserType);
            manageDriver(driver);
            CucumberReports.setDriver(driver);
            globalscenario = scenario;
        } else if (PropertiesRepository.getString("automation.type").equalsIgnoreCase(GlobalProperties.RESTAPIAUTOMATION)) {
            globalscenario = scenario;
        }
    }

    @After
    public void tearDown(Scenario scenario) throws IOException {
        if (PropertiesRepository.getString("automation.type").equalsIgnoreCase(GlobalProperties.WEBDRIVERAUTOMATION)) {
            globalscenario = scenario;
            File screenshot = takeScreenShots("screenshot");
            InputStream screenshotStream = new FileInputStream(screenshot);
            globalscenario.embed(IOUtils.toByteArray(screenshotStream), "image/png");
            // }
            if (driver != null) {
                DriverFactory.removeDriver(driver);
            }
        } else if (PropertiesRepository.getString("automation.type").equalsIgnoreCase(GlobalProperties.RESTAPIAUTOMATION)) {
            globalscenario = scenario;
            SoftAssertionHandler.assertAll();
            scenario.write("Response of the request is : " + RestAPIConstants.response.asString());
        }
    }

    private void manageDriver(WebDriver webDriver) {
        webDriver.manage().window().maximize();
        //webDriver.manage().window().setSize(new Dimension());
        webDriver.manage().deleteAllCookies();
        if (!GlobalProperties.BrowserType.equals(GlobalProperties.FIREFOX))
            webDriver.manage().window().maximize();
        webDriver.manage().timeouts().implicitlyWait(PropertiesRepository.getInt("global.implicit.wait"),
                TimeUnit.SECONDS);
    }

}
