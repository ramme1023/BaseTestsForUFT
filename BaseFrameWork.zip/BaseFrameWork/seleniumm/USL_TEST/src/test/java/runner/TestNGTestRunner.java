package runner;

import com.framework.cucumberhelper.BaseTestRunner;

public class TestNGTestRunner extends BaseTestRunner {


}
