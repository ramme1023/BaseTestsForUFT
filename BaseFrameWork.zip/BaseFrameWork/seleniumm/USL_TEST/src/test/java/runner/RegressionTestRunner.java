package runner;

import com.framework.config.GlobalProperties;
import com.framework.config.PropertiesRepository;
import com.framework.reports.CucumberAPIReports;
import com.framework.reports.CucumberReports;
import com.framework.utils.ExcelUtils;
import cucumber.api.CucumberOptions;
import cucumber.api.testng.AbstractTestNGCucumberTests;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;

@CucumberOptions(features = "src/test/resources/features", glue = { "stepdefinations" }, plugin = { "pretty",
		"html:target/cucumber-reports/cucumber-pretty", "json:target/cucumber-reports/CucumberTestReport.json",
		"rerun:target/cucumber-reports/rerun.txt" })
public class RegressionTestRunner extends AbstractTestNGCucumberTests {
	private static Logger logger = LogManager.getLogger(RegressionTestRunner.class);

	static {
		try {
			PropertiesRepository.loadAllProperties();
			ExcelUtils.setExcel(System.getProperty("user.dir") + PropertiesRepository.getString("testdata.excel.file"));
		} catch (Exception e) {
			logger.error("Unable to load properties files", e);
		}
	}

	@Parameters({ "browser", "testtype", "suitename", "environment" })
	@BeforeSuite
	public void setUp(@Optional String browserType, @Optional String testType, @Optional String suiteName,
			@Optional String environment) {
		if (PropertiesRepository.getString("automation.type").equalsIgnoreCase(GlobalProperties.WEBDRIVERAUTOMATION)) {
			GlobalProperties.BrowserType = browserType;
			GlobalProperties.TestType = testType;
			GlobalProperties.SuiteName = suiteName;
			GlobalProperties.Environment = environment;
		} else if (PropertiesRepository.getString("automation.type")
				.equalsIgnoreCase(GlobalProperties.RESTAPIAUTOMATION)) {
			GlobalProperties.TestType = testType;
			GlobalProperties.SuiteName = suiteName;
		}

	}

	@AfterSuite
	public void generateReport() {
		if (PropertiesRepository.getString("automation.type").equalsIgnoreCase(GlobalProperties.WEBDRIVERAUTOMATION)) {
			CucumberReports.generateCucumberReport(GlobalProperties.SuiteName);
		} else if (PropertiesRepository.getString("automation.type")
				.equalsIgnoreCase(GlobalProperties.RESTAPIAUTOMATION)) {
			CucumberAPIReports.generateCucumberReport(GlobalProperties.SuiteName);
		} else {
			CucumberAPIReports.generateCucumberReport(GlobalProperties.SuiteName);
		}
	}
}
