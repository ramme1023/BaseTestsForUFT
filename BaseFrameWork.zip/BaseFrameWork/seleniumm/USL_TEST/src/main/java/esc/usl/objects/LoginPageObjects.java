package esc.usl.objects;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class LoginPageObjects {
	
	@FindBy(id = "username")
	public static WebElement txtBoxUserName;
	
	@FindBy(name = "pw")
	public static WebElement txtBoxPassword;
	
	@FindBy(xpath = "//input[@id='Login']")
	public static WebElement btnLogin;

}
	
