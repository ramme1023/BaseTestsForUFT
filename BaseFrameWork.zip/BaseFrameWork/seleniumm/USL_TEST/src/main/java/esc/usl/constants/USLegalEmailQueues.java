package esc.usl.constants;

public class USLegalEmailQueues {
    public static final String westlawSupport = "westlaw support";
    public static final String specialityAppSupport = "speciality app support";
    public static final String litigationSupport = "litigation support";
}
