package esc.usl.pages;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;

import com.framework.utils.ExcelUtils;

import esc.usl.objects.ContactsPageObjects;

public class ContactPage extends BasePage {

	public ContactPage(WebDriver webDriver) {
		super(webDriver);
	}

	/***
	 * Method is used to verify Contact List
	 * 
	 * @return
	 */
	public boolean verifyContactList() {
		return elementHandler.isElementDisplayed(ContactsPageObjects.lnkContactNames);
	}

	/***
	 * Method is used to search the Contact
	 */
	public void searchContactName() {

		elementHandler.writeText(ContactsPageObjects.txtBoxSearchList,
				ExcelUtils.getDataByColumnName("Contact", "ContactName"));
		actionHandler.keyboardAction(Keys.ENTER);
		actionHandler.waitForSomeTime(3000);
		elementHandler.clickElement(ContactsPageObjects.lnkContactNames.get(0));
	}
	
	public boolean verifyContactPage() {
		return elementHandler.isElementDisplayed(ContactsPageObjects.btnNewServiceCase);
	}

}
