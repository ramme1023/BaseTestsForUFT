package esc.usl.constants;

public class USLegalProfileConstants {

	public static final String hdAgent = "agent";
	public static final String hdManager = "manager";
	public static final String hybridAgent = "hybrid agent";
	public static final String accountResolver = "account resolver";
	public static final String dqa = "dqa";
}
