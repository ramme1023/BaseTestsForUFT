package esc.usl.constants;

public class USLegalEnvironments {
	public static final String UAT = "UAT";
	public static final String MERGE = "MERGE";
	public static final String LRP2 = "LRP2";
	public static final String PPE = "PPE";

}
