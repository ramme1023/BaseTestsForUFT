package esc.usl.objects;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class HomePageObjects {

	@FindBy(xpath = "//button[@title='Show Navigation Menu']")
	public static WebElement dropDownShowNavigationMenu;

	@FindBy(xpath = "//a[@class='menuItem']//span[text()='Contacts']")
	public static WebElement lnkContacts;
	
	@FindBy(xpath = "//a[@class='menuItem']//span[text()='Home']")
	public static WebElement lnkHome;
	
	//@FindBy(xpath = "//a[@class='menuItem']//span[text()='Home']")
	//public static WebElement lnkHome;


}
