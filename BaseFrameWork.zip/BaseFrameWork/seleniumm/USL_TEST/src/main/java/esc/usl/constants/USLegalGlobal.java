package esc.usl.constants;

import java.util.List;

public class USLegalGlobal {

	public static String caseNumber = null;
	public static String status = "Closed";
	public static String completed = "Completed";
	public static String rejected = "Rejected";
	public static String accountName = null;
	public static String contactName = null;
	public static String account = "Account";
	public static String contact = "Contact";
	public static String userName = "test uslhdmanager";
	public static String accountResolver = "Test Acc Resolver USL";
	public static String hybridAgent = "Test Hybrid Agent USL";
	public static String helpdeskAgent = "Test HD Agent USL";
	public static String queueName = "WestLaw";
	public static String user = "User";
	public static String queue = "Queue";
	public static String caseOwner = null;
	public static String error = "Error:";
	public static String sampleDocument = "test_document";
	public static String salesOrg = null;
	public static String subBu = null;
	public static List<String> caseNumbers = null;
	public static String helpdeskManager = "Test HD Manager USL";
	public static String escalateOwner = "Test";
	
}
