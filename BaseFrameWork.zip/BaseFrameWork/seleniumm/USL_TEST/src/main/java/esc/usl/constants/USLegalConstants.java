package esc.usl.constants;

		import com.framework.config.PropertiesRepository;

public class USLegalConstants {
	public static final String ScreenShotPath = System.getProperty("user.dir")
			+ PropertiesRepository.getString("screenshot.path");
	public static final String featureSheetName = "Features";
	public static final String dataProviderMethod = "featureList";
	public static final String executionStatus = "Y";
	public static final String imageType = "image/png";
}
