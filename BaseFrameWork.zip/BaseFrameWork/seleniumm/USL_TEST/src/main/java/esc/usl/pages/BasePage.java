package esc.usl.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

import com.framework.config.PropertiesRepository;
import com.framework.handlers.ActionHandler;
import com.framework.handlers.ElementHandler;
import com.framework.handlers.JavaScriptHandler;
import com.framework.handlers.PopUpHandler;
import com.framework.handlers.WindowHandler;
import com.framework.utils.ExcelUtils;

import esc.usl.objects.CasesPageObjects;
import esc.usl.objects.ContactsPageObjects;
import esc.usl.objects.HomePageObjects;
import esc.usl.objects.LoginPageObjects;

public class BasePage {

	protected ElementHandler elementHandler;
	protected ActionHandler actionHandler;
	protected WindowHandler windowHandler;
	protected PopUpHandler popUpHandler;
	protected JavaScriptHandler javaScriptHandler;

	WebDriver driver = null;

	public BasePage(WebDriver webDriver) {
		// Init Object Classes
		PageFactory.initElements(webDriver, LoginPageObjects.class);
		PageFactory.initElements(webDriver, HomePageObjects.class);
		PageFactory.initElements(webDriver, CasesPageObjects.class);
		PageFactory.initElements(webDriver, ContactsPageObjects.class);

		this.driver = webDriver;
		elementHandler = new ElementHandler(driver);
		actionHandler = new ActionHandler(driver);
		windowHandler = new WindowHandler(driver);
		popUpHandler = new PopUpHandler(driver);
		javaScriptHandler = new JavaScriptHandler(driver);

		ExcelUtils.setExcel(System.getProperty("user.dir") + PropertiesRepository.getString("testdata.excel.file"));
	}

	/***
	 * Method is used to launch the application URL
	 */
	public void launchApplicationUrl(){
		driver.get(PropertiesRepository.getString("test.application.url"));
		elementHandler.setWebDriverWait(LoginPageObjects.txtBoxUserName);
	}

	/***
	 * Method is used to login to the application
	 */
	public void loginToApplication(){
		elementHandler.writeText(LoginPageObjects.txtBoxUserName, ExcelUtils.getDataByColumnName("Login","Username"), LoginPageObjects.txtBoxPassword);
		elementHandler.writeText(LoginPageObjects.txtBoxPassword, ExcelUtils.getDataByColumnName("Login","Password"), LoginPageObjects.btnLogin);
		elementHandler.clickElement(LoginPageObjects.btnLogin, HomePageObjects.dropDownShowNavigationMenu);
	}
}
