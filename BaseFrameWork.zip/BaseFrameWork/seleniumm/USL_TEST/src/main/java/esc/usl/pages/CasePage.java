package esc.usl.pages;

import org.openqa.selenium.WebDriver;

import esc.usl.objects.CasesPageObjects;
import esc.usl.objects.ContactsPageObjects;

public class CasePage extends BasePage {

	public CasePage(WebDriver webDriver) {
		super(webDriver);
		// TODO Auto-generated constructor stub
	}

	public boolean verifyCasePage() {
		return elementHandler.isElementDisplayed(CasesPageObjects.fieldCaseNumber);
	}
   public String returnCaseNumber() {
	   return elementHandler.getTextFromAttribute(CasesPageObjects.fieldCaseNumber, "title");
	   
   }
	}

	