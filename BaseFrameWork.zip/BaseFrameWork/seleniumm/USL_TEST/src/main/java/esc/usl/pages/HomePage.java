package esc.usl.pages;

import org.openqa.selenium.WebDriver;

import esc.usl.objects.ContactsPageObjects;
import esc.usl.objects.HomePageObjects;

public class HomePage extends BasePage {

	public HomePage(WebDriver webDriver) {
		super(webDriver);
	}

	/***
	 * Method is used to navigate to Contacts Tab
	 */
	public void navigateToContactsTab() {
		elementHandler.clickElement(HomePageObjects.dropDownShowNavigationMenu, HomePageObjects.lnkContacts);
		elementHandler.clickElement(HomePageObjects.lnkContacts);
	}

}
