 package esc.usl.objects;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class ContactsPageObjects {

	@FindBy(xpath = "//ol/li/span[text()='Contacts']")
	public static WebElement hdrContacts;

	@FindBy(xpath = "//input[@name='search-input']")
	public static WebElement txtBoxSearchTheList;

	@FindBy(xpath = "//table/tbody/tr/th/span/a")
	public static List<WebElement> lnkContactNames;

	@FindBy(xpath = "//input[@name='search-input']")
	public static WebElement txtBoxSearchList;
	
	@FindBy(xpath = "//div[@title='New Service Case']/parent::a")
	public static WebElement btnNewServiceCase;

}
