package esc.usl.objects;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class CasesPageObjects {
	
	@FindBy(xpath = "//ol/li/span[text()='Cases']")
	public static WebElement hdrCase;
	
	@FindBy(xpath = "//div[@class='slds-page-header__title slds-m-right--small slds-truncate slds-align-middle']/span/parent::div")
	public static WebElement fieldCaseNumber;

}
